import DictTag from './src/DictTag.vue'

export { DictTag }
