import Descriptions from './src/Descriptions.vue'
import DescriptionsItemLabel from './src/DescriptionsItemLabel.vue'

export { Descriptions, DescriptionsItemLabel }
