'use strict'

import extension from './extension'

export default {
  __init__: ['camundaModdleExtension'],
  camundaModdleExtension: ['type', extension]
}
