import MyPropertiesPanel from './PropertiesPanel.vue'

MyPropertiesPanel.install = function (Vue) {
  Vue.component(MyPropertiesPanel.name, MyPropertiesPanel)
}

export default MyPropertiesPanel
