import JsonEditor from './src/JsonEditor.vue'

export { JsonEditor }
