export interface ImageViewerProps {
  urlList?: string[]
  zIndex?: number
  initialIndex?: number
  infinite?: boolean
  hideOnClickModal?: boolean
  teleported?: boolean
  show?: boolean
}
