import Search from './src/Search.vue'

export { Search }
