import VerifySlide from './VerifySlide.vue'
import VerifyPoints from './VerifyPoints.vue'
import VerifyPictureWord from './VerifyPictureWord.vue'

export { VerifySlide, VerifyPoints, VerifyPictureWord }