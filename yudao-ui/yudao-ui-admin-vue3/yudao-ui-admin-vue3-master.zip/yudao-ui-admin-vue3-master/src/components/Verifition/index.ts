import Verify from './src/Verify.vue'

export { Verify }
