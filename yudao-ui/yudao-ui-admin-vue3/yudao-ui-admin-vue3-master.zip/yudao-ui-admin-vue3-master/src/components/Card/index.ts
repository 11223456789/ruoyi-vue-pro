import CardTitle from './src/CardTitle.vue'

export { CardTitle }
