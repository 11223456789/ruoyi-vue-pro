import CropperImage from './src/Cropper.vue'
import CropperAvatar from './src/CropperAvatar.vue'

export { CropperImage, CropperAvatar }
