/** 数据对照 Response VO */
export interface DataComparisonRespVO<T> {
  value: T
  reference: T
}
